KÖFTECİ POS - ANDROID STUDIO PROJESİ

Bu paket APK dosyası değil, Android Studio ile APK üretmek için proje kaynaklarıdır.

APK üretmek için:
1. Bilgisayara Android Studio kurun.
2. Android Studio > Open ile bu ZIP'ten çıkardığınız KofteciPOS klasörünü açın.
3. Gradle senkronizasyonunun bitmesini bekleyin. Android SDK Platform 35 kurulmalı.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK genellikle app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.
6. APK'yı telefona aktarın, dosyaya dokunup kurun. Android bilinmeyen uygulama izni isterse yalnızca kendi ürettiğiniz APK için izin verin.

ÖZELLİKLER:
- İlk menü fiyatları kullanıcının verdiği fiyatlarla eklendi.
- Satış, masa/paket/gel-al, nakit/kart takibi
- Ürün ekleme, fiyat değiştirme ve silme
- Günlük ciro ve gider özeti
- CSV satış dışa aktarma ve JSON yedekleme
- İnternet izni yok; WebView içindeki yerel HTML ile çalışır.

ÖNEMLİ:
- Bu uygulama deneme amaçlı basit kasa/adisyon takibidir. Resmî mali fiş/fatura veya ödeme terminali işlevi sağlamaz.
- Veriler uygulamanın WebView yerel depolamasında tutulur. Uygulamayı kaldırmadan önce JSON yedeği alın.
- Bu proje imzalı mağaza sürümü değildir; debug APK test amaçlıdır.
